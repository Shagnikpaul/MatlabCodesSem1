clc
clear


syms x y
f = exp(x) + exp(y)

ezsurf(f);