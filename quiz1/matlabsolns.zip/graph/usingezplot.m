clear
clc

% ezplot('x^2',[-2,2]);

ezplot('-x^2 + 2');