clc
clear


syms x


f = cos(x);




f2 = sin(x);
fplot(f,[-10,10]);
hold on
fplot(f2,[-10,10]);

