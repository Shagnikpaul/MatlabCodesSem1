clear
clc


x = 0:0.01:5;
y = exp(-x);
plot(x,y)